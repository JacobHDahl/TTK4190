% Project in TTK4190 Guidance and Control of Vehicles 
%
% Author:           Jacubi Dahl
% Study program:    MTTK


clear all;
clc;
addpath(genpath("C:\Users\jacob\Documents\Student\Fart�y\TTK4190\MSS"));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% USER INPUTS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h  = 0.1;    % sampling time [s]
Ns = 10000*10; %*10 % no. of samples

psi_ref = 10 * pi/180;  % desired yaw angle (rad)
U_d = 7;                % desired cruise speed (m/s)
               
% ship parameters 
m = 17.0677e6;          % mass (kg)
Iz = 2.1732e10;         % yaw moment of inertia about CO (kg m^3)
xg = -3.7;              % CG x-ccordinate (m)
L = 161;                % length (m)
B = 21.8;               % beam (m)
T = 8.9;                % draft (m)
KT = 0.7;               % propeller coefficient (-)
Dia = 3.3;              % propeller diameter (m)
rho = 1025;             % density of water (kg/m^3)
visc = 1e-6;            % kinematic viscousity at 20 degrees (m/s^2)
eps = 0.001;            % a small number added to ensure that the denominator of Cf is well defined at u=0
k = 0.1;                % form factor giving a viscous correction
t_thr = 0.05;           % thrust deduction number

% rudder limitations
delta_max  = 40 * pi/180;        % max rudder angle      (rad)
Ddelta_max = 5  * pi/180;        % max rudder derivative (rad/s)

% added mass matrix about CO
Xudot = -8.9830e5;
Yvdot = -5.1996e6;
Yrdot =  9.3677e5;
Nvdot =  Yrdot;
Nrdot = -2.4283e10;
MA = -[ Xudot 0    0 
        0 Yvdot Yrdot
        0 Nvdot Nrdot ];
MA_lin = MA(2:3,2:3);

% rigid-body mass matrix
MRB = [ m 0    0 
        0 m    m*xg
        0 m*xg Iz ];
MRB_lin = MRB(2:3,2:3);
    
Minv = inv(MRB + MA); % Added mass is included to give the total inertia
Minv_lin = inv(MRB_lin + MA_lin);

% ocean current in NED
Vc = 1;                             % current speed (m/s)
betaVc = deg2rad(45);               % current direction (rad)

% wind expressed in NED
Vw = 10;                   % wind speed (m/s)
betaVw = deg2rad(135);     % wind direction (rad)
rho_a = 1.247;             % air density at 10 deg celsius
cy = 0.95;                 % wind coefficient in sway
cn = 0.15;                 % wind coefficient in yaw
A_Lw = 10 * L;             % projected lateral area

%?w=???Vw??
% linear damping matrix (only valid for zero speed)
T1 = 20; T2 = 20; T6 = 10;

Xu = -(m - Xudot) / T1;
Yv = -(m - Yvdot) / T2;
Nr = -(Iz - Nrdot)/ T6;
D = diag([-Xu -Yv -Nr]);         % zero speed linear damping
D_lin = D(2:3,2:3);

%Linearized coriolis matrices
CRB_lin = [ 0 0 0 
    0  0  m*U_d
    0 0  m*xg*U_d];
CRB_lin = CRB_lin(2:3,2:3);
% coriolis due to added mass
CA_lin = [  0   0   0
        0   0   -Xudot*U_d 
      0    (Xudot-Yvdot)*U_d -Yrdot*U_d];
CA_lin = CA_lin(2:3,2:3);

% rudder coefficients (Section 9.5)
b = 2;
AR = 8;
CB = 0.8;

lambda = b^2 / AR;
tR = 0.45 - 0.28*CB;
CN = 6.13*lambda / (lambda + 2.25);
aH = 0.75;
xH = -0.4 * L;
xR = -0.5 * L;

X_delta2 = 0.5 * (1 - tR) * rho * AR * CN;
Y_delta = 0.25 * (1 + aH) * rho * AR * CN; 
N_delta = 0.25 * (xR + aH*xH) * rho * AR * CN;   

% input matrix
Bu = @(u_r,delta) [ (1-t_thr)  -u_r^2 * X_delta2 * delta
                        0      -u_r^2 * Y_delta
                        0      -u_r^2 * N_delta            ];

% linearized sway-yaw model (see (7.15)-(7.19) in Fossen (2021)) used
% for controller design. The code below should be modified.
N_lin = CRB_lin + CA_lin + D_lin;
b_lin = [-2*U_d*Y_delta -2*U_d*N_delta]';
%2c: tf
[NUM,DEN] = ss2tf(-Minv_lin*N_lin,Minv_lin*b_lin,[0 1],0);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                    
% Heading Controller
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% rudder control law
wb = 0.06;
zeta = 1;
wn = 1 / sqrt( 1 - 2*zeta^2 + sqrt( 4*zeta^4 - 4*zeta^2 + 2) ) * wb;
K_nomoto = NUM(3)/DEN(3);
T_nomoto = DEN(2)/DEN(3) - NUM(2)/(K_nomoto*DEN(3));%168.2;
m_reg = T_nomoto/K_nomoto;
d_reg = 1/K_nomoto;
Kp = m_reg*wn^2;
Kd = 2*zeta*wn*m_reg;
Ki = wn/10*Kp;

% initial states
eta = [0 0 pi]';
nu  = [0.1 0 0]';
delta = 0;
wn_ref = 0.03*2;
n = 0;
xd = [0 0 0]';
cum_error = 0;

% Part 3
Ja = 0;
PD = 1.5;
AEAO = 0.65;
z = 4;
[KT,KQ] = wageningen(Ja,PD,AEAO,z);

Qm = 0;

t_T = 0.05;

% Part 4
WP_struct = load("Wp.mat");
WP = WP_struct.WP;

x1 = WP(1,1);
y1 = WP(2,1);

x2 = WP(1,2);
y2 = WP(2,2);

nr_WP = 2;
WP_switch_rad = 10*L;

%part 4 
y_int = 0;
y_int_dot = 0;

k = 5; %tuning for ILOS

%part 5
% x = [yaw, yaw_rate, rudder_bias]'
%uses first order nomoto model for yaw-rate

NUM_r = [K_nomoto];
DEN_r = [T_nomoto 1];
[a_r,b_r,c_r,d_r] = tf2ss(NUM_r,DEN_r);

A_r = [0 1 0;
       0 a_r -K_nomoto/T_nomoto ;
       0 0 0];
B_r = [0 K_nomoto/T_nomoto 0]';
E_r = [0 0;
       1 0;
       0 1];
C_r = [1 0 0];

sampletime = h;

[A_r_d, B_r_d] = c2d(A_r,B_r,sampletime);
[~, E_r_d] = c2d(A_r,E_r,sampletime);
%check observability by obs = obsv(A_r_d,C_r); 
%rank(obs); if this is 3 then it's observable which it is

%kalman filter
y_nu = [0 0];
std_psi = 0.5 * pi/180;
std_r = 0.1 * pi/180;

% Estimation initialization
x_pred = xd;
P_pred = zeros(3);
x_mod = xd;
x_upd = x_pred;
P_upd = P_pred;

% Discretized system matrices
A_d = [1, h, 0; 0, 1 - h/T_nomoto, -K_nomoto*h/T_nomoto; 0, 0, 1];
B_d = [0; K_nomoto*h/T_nomoto; 0];
C_d = [1, 0, 0];
D_d = 0;
E_d = [0, 0; h, 0; 0, h];

% Tuning matrices for Kalman filter
Q_kalman = diag([deg2rad(0.05)^2, deg2rad(0.05)^2]);
R_kalman = std_psi;

        

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MAIN LOOP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
simdata = zeros(Ns+1,17);                % table of simulation data
nu_r_Data = zeros(Ns+1,3);
psi_ref_Data = zeros(Ns+1,1);

noise_Data = zeros(Ns+1,2);
kalman_Data = zeros(Ns+1,3);
for i=1:Ns+1
%     if(i/10 > 500)
%         psi_ref = -20*pi/180;
%     else
%         psi_ref = 10*pi/180;
%     end

    eta(3) = wrapTo2Pi(eta(3));
    
    % measurements
    y_nu(1) = normrnd(eta(3), std_psi);
    y_nu(2) = normrnd(nu(3), std_r);
    
    noise_Data(i,:) = y_nu;
    y = y_nu(1);
    
    % Kalman filter prediction and update
    
    K = (P_pred*(C_d'))*1/(C_d*P_pred*(C_d') + R_kalman);
    x_upd = x_pred + K*ssa(y - C_d*x_pred);
    eta(3) = x_upd(1);
    nu(3) = x_upd(2);
    
    kalman_Data(i,:) = x_upd;
    P_upd = (eye(3) - K*C_d)*P_pred*((eye(3) - K*C_d)') + K*R_kalman*(K');
    x_pred = A_d*x_upd + B_d*delta;
    P_pred = A_d*P_upd*(A_d') + E_d*Q_kalman*(E_d');
    
    %guidance law
    pos = [eta(1), eta(2)];
    wp_dist = (x2-eta(1))^2 + (y2-eta(2))^2;
    
    if wp_dist < WP_switch_rad^2
        
        nr_WP = nr_WP + 1;
        if nr_WP > 6
            x1 = x1;
            x2 = x2;
            y1 = y1;
            y2 = y2;
        else
            x1 = x2;
            y1 = y2;
            x2 = WP(1,nr_WP);
            y2 = WP(2,nr_WP);
        end
        
        
        
    end
    
    delta_gui = 800;    %look-ahead-distance
    Pi_p = atan2(y2-y1,x2-x1);
    path_info = [x1, y1, x2, y2, delta_gui, Pi_p,y_int,k];
    %[psi_ref, y_e,y_int_dot ] = guidance(pos, path_info);
    
%     crab_angle = atan(nu(2)/nu(1));   crab angle compensation
%     psi_ref = psi_ref - crab_angle;
    %psi_ref_Data(i)= psi_ref;
    
    
    %whatever
    Ad = [ 0 1 0
           0 0 1
           -wn_ref^3  -3*wn_ref^2  -3*wn_ref ];
    Bd = [ 0 0 wn_ref^3 ]';
    xd_dot = Ad * xd + Bd * psi_ref;    
    t = (i-1) * h;                      % time (s)
    R = Rzyx(0,0,eta(3));
    
    % current (should be added here)
    nu_r = nu - [Vc*cos(betaVc), Vc*sin(betaVc), 0]' ;
    u_c = Vc*cos(betaVc);
    nu_r_Data(i,:) = nu_r;
  
    
    gamma_w = eta(3)-betaVw-pi;
    C_Y = cy*sin(gamma_w);
    C_N = cn*sin(2*gamma_w);
    

    
    % wind (should be added here)
    if t > 200
        Ywind = 1/2*rho_a*Vw^2*C_Y*A_Lw; % expression for wind moment in sway should be added.
        Nwind = 1/2*rho_a*Vw^2*C_N*A_Lw*L; % expression for wind moment in yaw should be added.
    else
        Ywind = 0;
        Nwind = 0;
    end
    tau_env = [0,0,0]';%[0 Ywind Nwind]';
    
    % state-dependent time-varying matrices
    CRB = m * nu(3) * [ 0 -1 -xg 
                        1  0  0 
                        xg 0  0  ];
                    
    % coriolis due to added mass
    CA = [  0   0   Yvdot * nu_r(2) + Yrdot * nu_r(3)
            0   0   -Xudot * nu_r(1) 
          -Yvdot * nu_r(2) - Yrdot * nu_r(3)    Xudot * nu_r(1)   0];
    N = CRB + CA + D;
    
    % nonlinear surge damping
    Rn = L/visc * abs(nu_r(1));
    Cf = 0.075 / ( (log(Rn) - 2)^2 + eps);
    Xns = -0.5 * rho * (B*L) * (1 + k) * Cf * abs(nu_r(1)) * nu_r(1);
    
    % cross-flow drag
    Ycf = 0;
    Ncf = 0;
    dx = L/10;
    Cd_2D = Hoerner(B,T);
    for xL = -L/2:dx:L/2
        vr = nu_r(2);
        r = nu_r(3);
        Ucf = abs(vr + xL * r) * (vr + xL * r);
        Ycf = Ycf - 0.5 * rho * T * Cd_2D * Ucf * dx;
        Ncf = Ncf - 0.5 * rho * T * Cd_2D * xL * Ucf * dx;
    end
    d = -[Xns Ycf Ncf]';
    
    % reference models
    psi_d = xd(1);
    r_d = xd(2);
    u_d = U_d;
   
    % thrust 
    thr = rho * Dia^4 * KT * abs(n) * n;    % thrust command (N)
        
    % control law
    delta_unsat = -(Kp*ssa((eta(3)-xd(1))) + Ki*cum_error +  Kd*(nu(3)-xd(2)) ) ;              % rudder angle command (rad)
    
    % ship dynamics
    u = [ thr delta ]';
    tau = Bu(nu_r(1),delta) * u;
    nu_dot = Minv * (tau_env + tau - N * nu_r - d); 
    eta_dot = R * nu;    
    
    % Rudder saturation and dynamics (Sections 9.5.2)
    
    
    if abs(delta_unsat) >= delta_max
        delta_c = sign(delta_unsat)*delta_max;
        cum_error = cum_error - (h/Ki) * (delta_c-delta_unsat);
    else
        delta_c = delta_unsat;
    end
    
    
    delta_dot = delta_c - delta;
    if abs(delta_dot) >= Ddelta_max
        delta_dot = sign(delta_dot)*Ddelta_max;
    end    
    
    
    
    % propeller dynamics
    Im = 100000; Tm = 10; Km = 0.6;         % propulsion parameters
    %Hs = Km / (Tm*s+1);
    n_c = 10;                               % propeller speed (rps)
    
    %prop control
    T_prop = rho *Dia^4*KT*n*abs(n);
    Q = rho *Dia^5*KQ*n*abs(n);
    T_d = (U_d-u_c)*Xu / (t_T-1); % t = i?
    n_d = sign(T_d)*sqrt(abs(T_d) / (rho*Dia^4*KT));
    Q_d = rho *Dia^5*KQ*n_d*abs(n_d);
    y = Q_d/Km;
    Qm_dot = 1/Tm*(-Qm+y*Km);
    Q_f = 0;
    
    n_dot = (1/Im) * (Qm - Q -Q_f);        % should be changed in Part 3
    % store simulation data in a table (for testing)
    simdata(i,:) = [t n_c delta_c n delta eta' nu' u_d psi_d r_d nu_r'];       
     
    % Euler integration
    eta = euler2(eta_dot,eta,h);
    nu  = euler2(nu_dot,nu,h);
    delta = euler2(delta_dot,delta,h);   
    n  = euler2(n_dot,n,h);
    cum_error = euler2(eta(3)-xd(1),cum_error,h);
    xd = euler2(xd_dot,xd,h);
    Qm = euler2(Qm_dot,Qm,h);
    
    y_int = euler2(y_int_dot,y_int,h);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PLOTS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t       = simdata(:,1);                 % s
n_c     = 60 * simdata(:,2);            % rpm
delta_c = (180/pi) * simdata(:,3);      % deg
n       = 60 * simdata(:,4);            % rpm
delta   = (180/pi) * simdata(:,5);      % deg
x       = simdata(:,6);                 % m
y       = simdata(:,7);                 % m
psi     = (180/pi) * simdata(:,8);      % deg
u       = simdata(:,9);                 % m/s
v       = simdata(:,10);                % m/s
r       = (180/pi) * simdata(:,11);     % deg/s
u_d     = simdata(:,12);                % m/s
psi_d   = (180/pi) * simdata(:,13);     % deg
r_d     = (180/pi) * simdata(:,14);     % deg/s
nu_r    = [simdata(:,15) simdata(:,16) simdata(:,17)];

%noise states
yaw_noise = (180/pi)*noise_Data(:,1); %deg
yawrate_noise = (180/pi)*noise_Data(:,2); %deg/s

%kalman states
yaw_est = (180/pi)*kalman_Data(:,1);    %deg
yawrate_est = (180/pi)*kalman_Data(:,2); %deg/s
gyro_bias = kalman_Data(:,3);           

figure(1)
figure(gcf)
subplot(311)
plot(y,x,'linewidth',2); axis('equal')
title('North-East positions (m)'); xlabel('time (s)'); 
subplot(312)
plot(t,psi,t,psi_d,'linewidth',2);
title('Actual and desired yaw angles (deg)'); xlabel('time (s)');
legend('yaw', 'desired yaw');

subplot(313)
plot(t,r,t,r_d,'linewidth',2);
title('Actual and desired yaw rates (deg/s)'); xlabel('time (s)');
legend('r', 'desired r');

figure(2)
figure(gcf)
subplot(311)
plot(t,u,t,u_d,'linewidth',2);
title('Actual and desired surge velocities (m/s)'); xlabel('time (s)');
subplot(312)
plot(t,n,t,n_c,'linewidth',2);
title('Actual and commanded propeller speed (rpm)'); xlabel('time (s)');
subplot(313)
plot(t,delta,t,delta_c,'linewidth',2);
title('Actual and commanded rudder angles (deg)'); xlabel('time (s)');


figure(3) 
figure(gcf)
subplot(211)
plot(t,u,'linewidth',2);
title('Actual surge velocity (m/s)'); xlabel('time (s)');
subplot(212)
plot(t,v,'linewidth',2);
title('Actual sway velocity (m/s)'); xlabel('time (s)');

figure(4)
figure(gcf)
hold on
siz=size(WP);
for ii=1:(siz(2)-1)   
    plot([WP(2,ii), WP(2,ii+1)], [WP(1,ii), WP(1,ii+1)], 'r-x')
end

plot(y,x,'linewidth',2); axis('equal')
title('North-East positions (m)');
hold off

beta_c_arg = v./u;
beta_c = atan(beta_c_arg);
beta_c = rad2deg(beta_c);
v_relative = nu_r_Data(:,2);
root_arg = nu_r_Data(:,1).^2 + nu_r_Data(:,2).^2;
U_relative = sqrt(root_arg);
beta_arg= v_relative./U_relative;
beta = asin(beta_arg);
beta = rad2deg(beta);

course = psi + beta_c;

course_d = rad2deg(psi_ref_Data);

figure(5)
plot(beta_c)
hold on
plot(beta)
legend("beta_c","beta")
hold off

figure(6)
plot(course)
hold on
plot(course_d)
hold on
plot(psi)
hold off
legend("course","course desired","yaw")

figure(7)
subplot(211)
plot(yaw_noise);
hold on;
plot(psi);
hold off
legend("noise","no noise");
subplot(212)
plot(yawrate_noise);
hold on
plot(r);
hold off
legend("noise_rate","no_noise_rate");

figure(8)
subplot(311)
plot(yaw_est);
hold on;
plot(psi);
hold off
legend("yaw estimate","yaw");
subplot(312)
plot(yawrate_est);
hold on
plot(r);
hold off
legend("yawrate estimate","yawrate");
subplot(313)
plot(gyro_bias);
legend("gyrobias");

